# TravelingSalesman

  * ES Search is for running Hill Climb with parameters.
    * Number of searches
    * Number of iterations per search
  * GA Search is for running with Genetic Algorithm with paramaters.
    * Universal Ordered Crossover/ Partial Mapped Crossover.
    * Population Size
    * Max number of generations
