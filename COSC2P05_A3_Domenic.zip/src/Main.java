import TravelingSalesMan.TravelingSalesMan;

public class Main {
    public static void main(String[] args){
        new TravelingSalesMan();
    }
}
